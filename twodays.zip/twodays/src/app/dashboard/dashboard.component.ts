import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router'
import { HttpClient } from '@angular/common/http'

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  productList = []
  list = []
  search = ""
  
  constructor(  private route:Router, private http:HttpClient ) {
    this.fncLoginStatu()
  }

  ngOnInit(): void {
  }

  fncLoginStatu( ) {
    // session Control
    const session = sessionStorage.getItem("user");
    if (!session) {
      this.route.navigate(["login"])
    }else {
      // Product services Call
      const url = "https://www.jsonbulut.com/json/product.php";
      const objParams = {
        ref: "5380f5dbcc3b1021f93ab24c3a1aac24",
        start: "0"
      }

      this.http.get(url, { params: objParams })
      .toPromise()
      .then(response => {
        this.productList = response["Products"][0].bilgiler
        this.list = Object.assign([], this.productList)
        //console.log(JSON.stringify(this.list))
      }).catch( error => {
        console.error("Product Error : " + error)
      })


    }
  }


  fncGotoDetail( item ) {
    localStorage.setItem("item", JSON.stringify(item))
    this.route.navigate(["detail"])
  }



  // search Change
  fncSearchChange( txt ) {
    
    if (txt == "") {
      this.list = Object.assign([], this.productList)
    }else {
      // searching
      var searchList = []
      this.productList.forEach(item => {
        //console.log("title : " + item.productName)
        if( item.productName.toLowerCase().includes(txt.toLowerCase()) ) {
          console.log("title : " + item.productName)
          searchList.push(item)
        }
      })
      this.list = searchList
    }
  }


  fncUserExit() {
    sessionStorage.removeItem("token");
    // all session remove
    sessionStorage.clear();
    this.route.navigate(["login"])
  }


}
