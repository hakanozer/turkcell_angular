import { Component, OnInit, HostListener } from '@angular/core';
import { HttpClient } from '@angular/common/http'
import { Router } from '@angular/router'

enum keyAscii {
    enter = 13
}


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})

export class LoginComponent implements OnInit {


  mail = "";
  pass = "";
  errorStatu = false;

  constructor( private http: HttpClient, private route:Router ) { }

  ngOnInit(): void {
  }

  @HostListener('window:keyup', ['$event']) 
  keyEvent( evt: KeyboardEvent) {
    if ( evt.keyCode == keyAscii.enter) {
      this.fncLogin()
    }
  }

  fncLogin() {

    if (this.mail == "" || this.pass == "") {
      this.errorStatu = true
      alert("User name or password empty !");
    }else {

    const url = "https://www.jsonbulut.com/json/userLogin.php";
    const params = {
      ref: "5380f5dbcc3b1021f93ab24c3a1aac24",
      userEmail: this.mail,
      userPass: this.pass,
      face:"no"
    }

    this.http.get(url, { params: params })
    .toPromise()
    .then( response => {
      //console.log("Response : " + JSON.stringify(response))
      const durum = response["user"][0].durum
      const mesaj = response["user"][0].mesaj
      
      if (durum) {
        const bilgiler = response["user"][0].bilgiler
        // user login success
        sessionStorage.setItem("user", JSON.stringify(bilgiler));
        // page redirect
        this.route.navigate(["dashboard"])
      }else {
        this.errorStatu = true
        alert(mesaj);
      }
    })
    .catch( error => {
      console.error("Servives Error : " + error)
    })

  }


  }

}
