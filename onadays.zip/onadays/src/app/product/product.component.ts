import { Component, OnInit } from '@angular/core';
import * as data from "../model/data.json";

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent implements OnInit {

  list = []
  constructor() {
    this.list = data.products
   }

  ngOnInit(): void {
    // json to string -> localStorge setItem
    const dt = {
      name: "Mehmet Bilsin",
      age: "40",
      mail: "mehmet@mail.com"
    }
    const st = JSON.stringify(dt);
    localStorage.setItem("user", st);
  }

}
