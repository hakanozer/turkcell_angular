import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit {

  id = ""
  obj = null

  constructor( private route:ActivatedRoute ) { 
  }

  ngOnInit(): void {
    this.route.paramMap.subscribe( params => {
      this.id = params.get("id");
      // localStorge set
      localStorage.setItem("id", this.id);
    })

    const dt = localStorage.getItem("user");
    if (dt) {
      this.obj = JSON.parse(dt);
    }

  }


}
