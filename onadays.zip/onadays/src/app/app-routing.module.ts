import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// pages import
import {  ProductComponent } from './product/product.component';
import {  DetailComponent } from './detail/detail.component';

const routes: Routes = [
  { path:'product', component: ProductComponent },
  { path:'detail/:id', component: DetailComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
