import { Component, Input } from '@angular/core';
import { Router } from '@angular/router'


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  // list create
  list = []
  constructor( private route:Router ) {
    console.log("constructor call");
    // for
    for ( let i = 0; i<10; i++ ) {
      const obj = { id: i, name: "Ali - "+i, mail: "ali@ali.com", icon: '../assets/icon.png' }
      // item add
      this.list.push(obj);
    }
    console.log(JSON.stringify(this.list));
  }

  fncDeleteItem( id ) {
    console.log("Delete " + id)
    this.list.splice(id, 1);
  }

  person = 'Mehmet Bilsin';
  data = "";

  // user login
  mail = "";
  pass = "";
  fncLogin() {
    if(this.mail == "ali@ali.com" && this.pass == "12345") {
      alert("Login Success");
    }else {
      alert("Login fail");
    }
  }


  // fnc create
  fncSend() {
    alert("Hello Angular")
  }


  fncDetailHistory() {
    // localStorge getItem
    const id = localStorage.getItem("id");
    if (id) {
      console.log("id : " + id);
      // Redirect
      this.route.navigate(["detail",id])
    }
  }

  fncClearHistory() {
    // localStorge remove
    localStorage.removeItem("id");
    // all localStorge remove
    localStorage.clear();
    // redirect
    this.route.navigate([""])
  }


}
